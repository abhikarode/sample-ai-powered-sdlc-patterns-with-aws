/**
 * Document Management Lambda Function - RED Phase
 * Test-driven implementation for document management API endpoints
 */
import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from 'aws-lambda';
export declare const handler: (event: APIGatewayProxyEvent, context: Context) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=index.d.ts.map