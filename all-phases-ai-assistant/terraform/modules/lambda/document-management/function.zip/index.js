"use strict";
/**
 * Document Management Lambda Function - RED Phase
 * Test-driven implementation for document management API endpoints
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_bedrock_agent_1 = require("@aws-sdk/client-bedrock-agent");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client_s3_1 = require("@aws-sdk/client-s3");
// AWS clients configured for us-west-2 region per steering guidelines
const s3Client = new client_s3_1.S3Client({
    region: 'us-west-2'
});
const dynamoClient = new client_dynamodb_1.DynamoDBClient({
    region: 'us-west-2'
});
const bedrockClient = new client_bedrock_agent_1.BedrockAgentClient({
    region: 'us-west-2'
});
const handler = async (event, context) => {
    const startTime = Date.now();
    const requestId = context.awsRequestId;
    console.log('Document management request received:', {
        requestId,
        method: event.httpMethod,
        path: event.path,
        pathParameters: event.pathParameters
    });
    try {
        // Validate authorization
        if (!event.requestContext?.authorizer?.claims?.sub) {
            console.warn('Authorization failed:', { requestId });
            return createErrorResponse(401, 'Unauthorized - missing user authentication');
        }
        const userId = event.requestContext.authorizer.claims.sub;
        const userRole = event.requestContext.authorizer.claims['custom:role'] || 'user';
        console.log('User authenticated:', { requestId, userId, userRole });
        // Route to appropriate handler based on HTTP method and path
        const method = event.httpMethod;
        const path = event.path;
        const pathParameters = event.pathParameters;
        if (method === 'GET' && path === '/documents') {
            return await handleListDocuments(userId, userRole, requestId);
        }
        else if (method === 'DELETE' && pathParameters?.id) {
            return await handleDeleteDocument(pathParameters.id, userId, userRole, requestId);
        }
        else if (method === 'GET' && path === '/documents/status') {
            return await handleDocumentProcessingStatus(userId, userRole, requestId);
        }
        else {
            return createErrorResponse(404, 'Endpoint not found');
        }
    }
    catch (error) {
        console.error('Document management error:', { requestId, error });
        return createErrorResponse(500, 'Internal server error during document management');
    }
};
exports.handler = handler;
/**
 * Handle GET /documents - List user documents with Knowledge Base sync status
 * Requirements: US-005 (Document Management), US-005a (Document Viewing)
 */
async function handleListDocuments(userId, userRole, requestId) {
    try {
        console.log('Listing documents for user:', { requestId, userId, userRole });
        let documents = [];
        if (userRole === 'admin') {
            // Admins can see all documents
            documents = await getAllDocuments(requestId);
        }
        else {
            // Regular users can only see their own documents
            documents = await getUserDocuments(userId, requestId);
        }
        // Enrich documents with current Knowledge Base sync status
        const enrichedDocuments = await enrichDocumentsWithSyncStatus(documents, requestId);
        const processingTime = Date.now() - Date.now();
        console.log('Documents listed successfully:', {
            requestId,
            documentCount: enrichedDocuments.length,
            processingTime: `${processingTime}ms`
        });
        return {
            statusCode: 200,
            headers: getCorsHeaders(),
            body: JSON.stringify({
                success: true,
                data: {
                    documents: enrichedDocuments,
                    totalCount: enrichedDocuments.length,
                    userRole,
                    timestamp: new Date().toISOString(),
                    processingTime: `${processingTime}ms`
                }
            })
        };
    }
    catch (error) {
        console.error('Error listing documents:', { requestId, error });
        return createErrorResponse(500, 'Failed to retrieve documents');
    }
}
/**
 * Handle DELETE /documents/{id} - Delete document with Knowledge Base cleanup
 * Requirements: US-005 (Document Management)
 */
async function handleDeleteDocument(documentId, userId, userRole, requestId) {
    try {
        console.log('Deleting document:', { requestId, documentId, userId, userRole });
        // Get document metadata to verify ownership and get S3 details
        const document = await getDocumentById(documentId, requestId);
        if (!document) {
            return createErrorResponse(404, 'Document not found');
        }
        // Check permissions - users can only delete their own documents, admins can delete any
        if (userRole !== 'admin' && document.uploadedBy !== userId) {
            console.warn('Permission denied for document deletion:', {
                requestId,
                documentId,
                documentOwner: document.uploadedBy,
                requestingUser: userId
            });
            return createErrorResponse(403, 'Permission denied - you can only delete your own documents');
        }
        // Delete from S3 first
        try {
            await s3Client.send(new client_s3_1.DeleteObjectCommand({
                Bucket: document.s3Bucket,
                Key: document.s3Key
            }));
            console.log('Document deleted from S3:', { requestId, documentId, s3Key: document.s3Key });
        }
        catch (s3Error) {
            console.error('S3 deletion failed:', { requestId, documentId, error: s3Error });
            return createErrorResponse(500, 'Failed to delete document from storage');
        }
        // Delete metadata from DynamoDB
        try {
            await dynamoClient.send(new client_dynamodb_1.DeleteItemCommand({
                TableName: process.env.DOCUMENTS_TABLE,
                Key: {
                    PK: { S: `DOC#${documentId}` },
                    SK: { S: 'METADATA' }
                }
            }));
            console.log('Document metadata deleted from DynamoDB:', { requestId, documentId });
        }
        catch (dynamoError) {
            console.error('DynamoDB deletion failed:', { requestId, documentId, error: dynamoError });
            return createErrorResponse(500, 'Failed to delete document metadata');
        }
        // Note: Knowledge Base cleanup happens automatically during next sync
        // The document will be removed from the vector index when the data source is synchronized
        const processingTime = Date.now() - Date.now();
        console.log('Document deleted successfully:', {
            requestId,
            documentId,
            processingTime: `${processingTime}ms`
        });
        return {
            statusCode: 200,
            headers: getCorsHeaders(),
            body: JSON.stringify({
                success: true,
                data: {
                    message: 'Document deleted successfully',
                    documentId,
                    fileName: document.fileName,
                    knowledgeBaseCleanup: 'Will be removed from Knowledge Base during next sync',
                    timestamp: new Date().toISOString(),
                    processingTime: `${processingTime}ms`
                }
            })
        };
    }
    catch (error) {
        console.error('Error deleting document:', { requestId, documentId, error });
        return createErrorResponse(500, 'Failed to delete document');
    }
}
/**
 * Handle GET /documents/status - Get document processing status with ingestion job tracking
 * Requirements: US-005 (Document Management)
 */
async function handleDocumentProcessingStatus(userId, userRole, requestId) {
    try {
        console.log('Getting document processing status:', { requestId, userId, userRole });
        // Get current ingestion jobs from Knowledge Base
        const ingestionJobs = await getCurrentIngestionJobs(requestId);
        // Get documents with processing status
        let documents = [];
        if (userRole === 'admin') {
            documents = await getAllDocuments(requestId);
        }
        else {
            documents = await getUserDocuments(userId, requestId);
        }
        // Filter to documents that are currently processing or recently processed
        const processingDocuments = documents.filter(doc => doc.knowledgeBaseStatus === 'pending' ||
            doc.knowledgeBaseStatus === 'ingesting' ||
            (doc.knowledgeBaseStatus === 'failed' && doc.retryCount && doc.retryCount < 3));
        // Create processing status summary
        const statusSummary = {
            totalDocuments: documents.length,
            pendingIngestion: documents.filter(d => d.knowledgeBaseStatus === 'pending').length,
            currentlyIngesting: documents.filter(d => d.knowledgeBaseStatus === 'ingesting').length,
            synced: documents.filter(d => d.knowledgeBaseStatus === 'synced').length,
            failed: documents.filter(d => d.knowledgeBaseStatus === 'failed').length,
            activeIngestionJobs: ingestionJobs.filter(j => j.status === 'IN_PROGRESS').length,
            completedIngestionJobs: ingestionJobs.filter(j => j.status === 'COMPLETE').length,
            failedIngestionJobs: ingestionJobs.filter(j => j.status === 'FAILED').length
        };
        const processingTime = Date.now() - Date.now();
        console.log('Document processing status retrieved:', {
            requestId,
            statusSummary,
            processingTime: `${processingTime}ms`
        });
        return {
            statusCode: 200,
            headers: getCorsHeaders(),
            body: JSON.stringify({
                success: true,
                data: {
                    statusSummary,
                    processingDocuments,
                    ingestionJobs,
                    userRole,
                    timestamp: new Date().toISOString(),
                    processingTime: `${processingTime}ms`
                }
            })
        };
    }
    catch (error) {
        console.error('Error getting document processing status:', { requestId, error });
        return createErrorResponse(500, 'Failed to retrieve document processing status');
    }
}
// Helper functions
async function getAllDocuments(requestId) {
    try {
        const response = await dynamoClient.send(new client_dynamodb_1.ScanCommand({
            TableName: process.env.DOCUMENTS_TABLE,
            FilterExpression: 'SK = :sk AND begins_with(PK, :docPrefix)',
            ExpressionAttributeValues: {
                ':sk': { S: 'METADATA' },
                ':docPrefix': { S: 'DOC#' }
            }
        }));
        return response.Items?.map(item => mapDynamoItemToDocument(item)).filter((doc) => doc !== null) || [];
    }
    catch (error) {
        console.error('Error getting all documents:', { requestId, error });
        return [];
    }
}
async function getUserDocuments(userId, requestId) {
    try {
        const response = await dynamoClient.send(new client_dynamodb_1.QueryCommand({
            TableName: process.env.DOCUMENTS_TABLE,
            IndexName: 'GSI1',
            KeyConditionExpression: 'GSI1PK = :userPK',
            ExpressionAttributeValues: {
                ':userPK': { S: `USER#${userId}` }
            }
        }));
        return response.Items?.map(item => mapDynamoItemToDocument(item)).filter((doc) => doc !== null) || [];
    }
    catch (error) {
        console.error('Error getting user documents:', { requestId, userId, error });
        return [];
    }
}
async function getDocumentById(documentId, requestId) {
    try {
        const response = await dynamoClient.send(new client_dynamodb_1.QueryCommand({
            TableName: process.env.DOCUMENTS_TABLE,
            KeyConditionExpression: 'PK = :pk AND SK = :sk',
            ExpressionAttributeValues: {
                ':pk': { S: `DOC#${documentId}` },
                ':sk': { S: 'METADATA' }
            }
        }));
        if (response.Items && response.Items.length > 0) {
            return mapDynamoItemToDocument(response.Items[0]);
        }
        return null;
    }
    catch (error) {
        console.error('Error getting document by ID:', { requestId, documentId, error });
        return null;
    }
}
async function enrichDocumentsWithSyncStatus(documents, requestId) {
    try {
        // Get current ingestion jobs to provide real-time status
        const ingestionJobs = await getCurrentIngestionJobs(requestId);
        return documents.map(doc => {
            // Find related ingestion job if exists
            const relatedJob = ingestionJobs.find(job => job.jobId === doc.ingestionJobId);
            if (relatedJob) {
                // Update status based on current job status
                return {
                    ...doc,
                    currentIngestionJob: {
                        jobId: relatedJob.jobId,
                        status: relatedJob.status,
                        startedAt: relatedJob.startedAt,
                        completedAt: relatedJob.completedAt,
                        statistics: relatedJob.statistics
                    }
                };
            }
            return doc;
        });
    }
    catch (error) {
        console.error('Error enriching documents with sync status:', { requestId, error });
        // Return documents without enrichment if there's an error
        return documents;
    }
}
async function getCurrentIngestionJobs(requestId) {
    try {
        const response = await bedrockClient.send(new client_bedrock_agent_1.ListIngestionJobsCommand({
            knowledgeBaseId: process.env.KNOWLEDGE_BASE_ID,
            dataSourceId: process.env.DATA_SOURCE_ID,
            maxResults: 50
        }));
        const jobs = [];
        if (response.ingestionJobSummaries) {
            for (const jobSummary of response.ingestionJobSummaries) {
                // Get detailed job information
                const jobDetail = await bedrockClient.send(new client_bedrock_agent_1.GetIngestionJobCommand({
                    knowledgeBaseId: process.env.KNOWLEDGE_BASE_ID,
                    dataSourceId: process.env.DATA_SOURCE_ID,
                    ingestionJobId: jobSummary.ingestionJobId
                }));
                jobs.push({
                    jobId: jobSummary.ingestionJobId,
                    status: jobSummary.status,
                    startedAt: jobSummary.startedAt,
                    completedAt: jobSummary.updatedAt,
                    statistics: jobDetail.ingestionJob?.statistics
                });
            }
        }
        return jobs;
    }
    catch (error) {
        console.error('Error getting current ingestion jobs:', { requestId, error });
        return [];
    }
}
function mapDynamoItemToDocument(item) {
    // Validate that this is actually a document record
    if (!item.PK?.S?.startsWith('DOC#') || !item.documentId?.S || !item.fileName?.S) {
        console.warn('Invalid document record found, skipping:', {
            PK: item.PK?.S,
            hasDocumentId: !!item.documentId?.S,
            hasFileName: !!item.fileName?.S
        });
        return null;
    }
    // Validate required fields
    const documentId = item.documentId?.S;
    const fileName = item.fileName?.S;
    const uploadDate = item.uploadDate?.S;
    const uploadedBy = item.uploadedBy?.S;
    if (!documentId || !fileName || !uploadDate || !uploadedBy) {
        console.warn('Document record missing required fields, skipping:', {
            documentId, fileName, uploadDate, uploadedBy
        });
        return null;
    }
    return {
        documentId,
        fileName,
        originalName: item.originalName?.S || fileName,
        contentType: item.contentType?.S || 'application/octet-stream',
        fileSize: parseInt(item.fileSize?.N || '0'),
        uploadedBy,
        uploadDate,
        s3Key: item.s3Key?.S || '',
        s3Bucket: item.s3Bucket?.S || process.env.DOCUMENTS_BUCKET || '',
        status: (item.status?.S || 'unknown'),
        knowledgeBaseStatus: (item.knowledgeBaseStatus?.S || 'pending'),
        lastSyncDate: item.lastSyncDate?.S,
        ingestionJobId: item.ingestionJobId?.S,
        failureReason: item.failureReason?.S,
        retryCount: item.retryCount?.N ? parseInt(item.retryCount.N) : undefined
    };
}
function createErrorResponse(statusCode, message) {
    return {
        statusCode,
        headers: getCorsHeaders(),
        body: JSON.stringify({
            success: false,
            error: {
                message: message,
                timestamp: new Date().toISOString()
            }
        })
    };
}
function getCorsHeaders() {
    return {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
        'Access-Control-Allow-Methods': 'GET,DELETE,OPTIONS'
    };
}
//# sourceMappingURL=index.js.map